
function el(id){return document.getElementById(id)}
function escapeHtml(s){ if(s===undefined||s===null) return ''; return String(s).replace(/[&<>"]/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])); }
function downloadBlob(filename, content){ const a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([content],{type:'text/csv'})); a.download=filename; a.click(); setTimeout(()=>URL.revokeObjectURL(a.href),1000) }

function TableManager(config){
  this.key = config.storageKey;
  this.columns = config.columns;
  this.tableBody = document.getElementById(config.tableBodyId);
  this.searchInput = document.getElementById(config.searchInputId);
  this.searchTeacher = document.getElementById(config.searchTeacherId);
  this.searchClass = document.getElementById(config.searchClassId);
  this.searchPeriods = document.getElementById(config.searchPeriodsId);
  this.addBtn = document.getElementById(config.addBtnId);
  this.importBtn = document.getElementById(config.importBtnId);
  this.exportBtn = document.getElementById(config.exportBtnId);
  this.exportPdfBtn = document.getElementById(config.exportPdfId);
  this.printPreviewBtn = document.getElementById(config.printPreviewId);
  this.clearBtn = document.getElementById(config.clearBtnId);
  this.fileInput = document.getElementById(config.fileInputId);
  this.modal = document.getElementById(config.modalId);
  this.modalTitle = document.getElementById(config.modalTitleId);
  this.saveBtn = document.getElementById(config.saveBtnId);
  this.cancelBtn = document.getElementById(config.cancelBtnId);
  this.formFields = config.formFieldIds.map(function(id){ return document.getElementById(id); });
  this.data = JSON.parse(localStorage.getItem(this.key) || 'null');
  if(!this.data){ this.data = config.initialData || []; localStorage.setItem(this.key, JSON.stringify(this.data)); }
  this.regenSerials = function(){ if(!this.columns.find(function(c){return c.id==='sr'})) return; for(var i=0;i<this.data.length;i++){ this.data[i].sr = String(i+1); } };
  this.getNextSr = function(){ if(!this.columns.find(function(c){return c.id==='sr'})) return ''; return String(this.data.length+1); };
  var self=this;
  this.render = function(){
    self.regenSerials();
    self.tableBody.innerHTML='';
    var display=[];
    var q = self.searchInput && self.searchInput.value.toLowerCase().trim();
    var t = self.searchTeacher && self.searchTeacher.value.toLowerCase().trim();
    var c = self.searchClass && self.searchClass.value.toLowerCase().trim();
    var p = self.searchPeriods && self.searchPeriods.value.toLowerCase().trim();
    for(var i=0;i<self.data.length;i++){
      var r = self.data[i]; var ok=true;
      if(q) ok = ok && Object.keys(r).some(function(k){ return (r[k]||'').toString().toLowerCase().includes(q); });
      if(t) ok = ok && (r.teacher||'').toLowerCase().includes(t);
      if(c) ok = ok && (r.class||'').toLowerCase().includes(c);
      if(p) ok = ok && (r.periods||'').toLowerCase().includes(p);
      if(ok) display.push({rec:r, idx:i});
    }
    self.currentDisplay = display;
    display.forEach(function(item, displayIndex){
      var r=item.rec; var orig=item.idx;
      var tr = document.createElement('tr');
      var tds='';
      self.columns.forEach(function(col){ tds += '<td>'+escapeHtml(r[col.id]||'')+'</td>'; });
      tds += '<td><button class="button secondary" onclick="'+self.key+'_onEditOrig('+orig+')">Edit</button> <button class="button secondary" style="background:#fee2e2;color:#b91c1c" onclick="'+self.key+'_onDeleteOrig('+orig+')">Delete</button></td>';
      tr.innerHTML = tds;
      self.tableBody.appendChild(tr);
    });
    localStorage.setItem(self.key, JSON.stringify(self.data));
  };
  if(this.addBtn) this.addBtn.addEventListener('click', function(){ self.modalTitle.textContent='Add New'; self.formFields.forEach(function(f,idx){ f.value = (self.columns[idx].id==='sr')? self.getNextSr() : ''; }); self.modal.style.display='flex'; self.saveBtn.onclick = function(){ var rec={}; self.columns.forEach(function(col,idx){ rec[col.id] = self.formFields[idx].value.trim(); }); if(self.columns.find(function(c){return c.id==='sr'}) && !rec.sr) rec.sr = self.getNextSr(); self.data.push(rec); self.modal.style.display='none'; self.render(); }; });
  if(this.cancelBtn) this.cancelBtn.addEventListener('click', function(){ self.modal.style.display='none'; });
  if(this.clearBtn) this.clearBtn.addEventListener('click', function(){ if(self.searchInput) self.searchInput.value=''; if(self.searchTeacher) self.searchTeacher.value=''; if(self.searchClass) self.searchClass.value=''; if(self.searchPeriods) self.searchPeriods.value=''; self.render(); });

  function applyFilters(){ self.render(); }
  if(this.searchInput) this.searchInput.addEventListener('input', applyFilters);
  if(this.searchTeacher) this.searchTeacher.addEventListener('input', applyFilters);
  if(this.searchClass) this.searchClass.addEventListener('input', applyFilters);
  if(this.searchPeriods) this.searchPeriods.addEventListener('input', applyFilters);

  if(this.importBtn && this.fileInput){
    this.importBtn.addEventListener('click', function(){ self.fileInput.click(); });
    this.fileInput.addEventListener('change', function(e){ var file=e.target.files[0]; if(!file) return; var reader=new FileReader(); reader.onload=function(ev){ var text=ev.target.result; var lines=text.split(/\r?\n/).map(l=>l.trim()).filter(l=>l); if(lines.length<1) return alert('CSV empty'); var header=lines[0].split(',').map(h=>h.trim().replace(/^"|"$/g,'')); var idx={}; self.columns.forEach(function(col){ var possible=[col.label,col.id]; var found=-1; for(var i=0;i<header.length;i++){ if(possible.map(p=>p.toLowerCase()).indexOf(header[i].toLowerCase())!==-1){ found=i; break; } } idx[col.id]=found; }); var newRows=[]; for(var i=1;i<lines.length;i++){ var cols=lines[i].split(',').map(c=>c.replace(/^"|"$/g,'').trim()); var row={}; self.columns.forEach(function(col){ row[col.id] = (idx[col.id]!==-1 && idx[col.id]<cols.length)? cols[idx[col.id]] : '' }); if(self.columns.some(col=> row[col.id])) newRows.push(row); } if(newRows.length){ self.data = self.data.concat(newRows); self.render(); alert('Imported '+newRows.length+' rows'); } self.fileInput.value=''; }; reader.readAsText(file); }); }

  if(this.exportBtn) this.exportBtn.addEventListener('click', function(){ var rows=[self.columns.map(c=>c.label)]; self.data.forEach(r=> rows.push(self.columns.map(c=> r[c.id]||''))); var csv=rows.map(r=> r.map(c=>'"'+String(c).replace(/"/g,'""')+'"').join(',')).join('\n'); downloadBlob(self.key+'_export.csv', csv); });

  function buildExportHtml(list){
    var rows = list.map(r=> '<tr>'+ self.columns.map(c=> '<td style="padding:6px;border:1px solid #ddd">'+ escapeHtml(r[c.id]||'') +'</td>').join('') +'</tr>').join('');
    var head = '<tr>' + self.columns.map(c=> '<th style="padding:8px;border:1px solid #ddd;background:#e6f2ff">'+ escapeHtml(c.label) +'</th>').join('') + '</tr>';
    var today = new Date(); var dd = String(today.getDate()).padStart(2,'0'); var mm = String(today.getMonth()+1).padStart(2,'0'); var yyyy = today.getFullYear();
    var dateStr = dd + '/' + mm + '/' + yyyy;
    var headerText = '<div style="text-align:center;margin-bottom:8px;font-size:20pt;font-weight:600">Dept. of Modern Education — ' + dateStr + '</div>';
    var html = '<html><head><title>Export PDF</title><style>html,body{height:100%;margin:0}body{font-family:Poppins,Arial,Helvetica,sans-serif;margin:0;padding:0} .letter-bg{position:fixed; inset:0; background-image:url("letterhead.png"); background-size:cover; background-repeat:no-repeat; background-position:center; z-index:-1} .content{padding:2.5in 0.75in 1in 0.75in;} table{border-collapse:collapse;width:100%; background:rgba(255,255,255,0.95)} th,td{border:1px solid #ddd;padding:8px; font-size:20pt} h2{margin:0 0 10px 0}</style></head><body><div class="letter-bg"></div><div class="content">' + headerText + '<table class="print-table"><thead>' + head + '</thead><tbody>' + rows + '</tbody></table></div></body></html>'; return html; }

  if(this.exportPdfBtn) this.exportPdfBtn.addEventListener('click', function(){ var list = self.currentDisplay && self.currentDisplay.length ? self.currentDisplay.map(item=>item.rec) : self.data; var html = buildExportHtml(list); var w = window.open('','_blank'); w.document.write(html); w.document.close(); w.focus(); setTimeout(function(){ w.print(); },700); });

  if(this.printPreviewBtn) this.printPreviewBtn.addEventListener('click', function(){ var list = self.currentDisplay && self.currentDisplay.length ? self.currentDisplay.map(item=>item.rec) : self.data; var html = buildExportHtml(list); var w = window.open('','_blank'); w.document.write(html); w.document.close(); w.focus(); });

  window[this.key + '_onEditOrig'] = function(orig){ var r = self.data[orig]; self.modalTitle.textContent = 'Edit Record'; self.formFields.forEach(function(f,idx){ f.value = r[self.columns[idx].id] || ''; }); self.modal.style.display = 'flex'; self.saveBtn.onclick = function(){ var rec = {}; self.columns.forEach(function(col,idx){ rec[col.id] = self.formFields[idx].value.trim(); }); self.data[orig] = rec; self.modal.style.display = 'none'; self.render(); }; };
  window[this.key + '_onDeleteOrig'] = function(orig){ if(confirm('Delete this record?')){ self.data.splice(orig,1); self.render(); } };
  this.render();
}

